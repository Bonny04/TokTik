<?php
session_start();
session_destroy();
header("Location: /Html/Log-in.php");
exit;
?>
