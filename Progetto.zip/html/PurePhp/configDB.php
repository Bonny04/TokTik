<?php
$host = "192.168.0.10";
$dbname = "toktik";
$username = "userTokTik";
$password = "Gruppo3TokTik";
$port = 30175

$mysqli = new mysqli(hostname: $host, username: $username, password: $password, database: $dbname, port: $port);

return $mysqli;

?>
